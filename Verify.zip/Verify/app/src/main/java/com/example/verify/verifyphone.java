 package com.example.verify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

 public class verifyphone extends AppCompatActivity {
   String getotpbackend;
    EditText inputnumber1, inputnumber2, inputnumber3, inputnumber4, inputnumber5, inputnumber6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifyphone);

        Button verifybuttonclick = findViewById(R.id.verify);
        inputnumber1=findViewById(R.id.input1);
        inputnumber2=findViewById(R.id.input2);
        inputnumber3=findViewById(R.id.input3);
        inputnumber4=findViewById(R.id.input4);
        inputnumber5=findViewById(R.id.input5);
        inputnumber6=findViewById(R.id.input6);
        TextView textView=findViewById(R.id.textmobileshownumber);
        textView.setText(String.format("+91-%s",getIntent().getStringExtra("mobile")));
getotpbackend= getIntent().getStringExtra("backendotp");
        verifybuttonclick.setOnClickListener(v -> {

                    if(!inputnumber1.getText().toString().trim().isEmpty() &&  !inputnumber2.getText().toString().trim().isEmpty()){
                       String entercodeotp= inputnumber1.getText().toString() +
                               inputnumber2.getText().toString() +
                               inputnumber3.getText().toString() +
                               inputnumber4.getText().toString() +
                               inputnumber5.getText().toString() +
                               inputnumber6.getText().toString() ;
                       if(getotpbackend!=null){
                           PhoneAuthCredential phoneAuthCredential= PhoneAuthProvider.getCredential(
                                   getotpbackend,entercodeotp
                           );
                           FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                               @Override
                               public void onComplete(@NonNull  Task<AuthResult> task) {
                                    if(task.isSuccessful()){
                                        Intent intent=new Intent(getApplicationContext(),dashboard.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(intent);
                                    }else {
                                        Toast.makeText(verifyphone.this,"Error Enter correct OTP", Toast.LENGTH_SHORT).show();
                                    }
                               }
                           });
                       }else {
                           Toast.makeText(verifyphone.this,"Error Please check Internet Connection", Toast.LENGTH_SHORT).show();

                       }
                    //    Toast.makeText(verifyphone.this,"otp verify",Toast.LENGTH_SHORT).show();
                    }else{

                        Toast.makeText(verifyphone.this,"please enter all number",Toast.LENGTH_SHORT).show();
                    }
                }
        );

        numberotpmove();
//short cut
//findViewById(R.id.requestagain).setOnClickListener(new View.OnClickListener() {
//    @Override
//    public void onClick(View v) {
//
//    }
//});
TextView resendlabel= findViewById(R.id.requestagain);
resendlabel.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                "+91" +  getIntent().getStringExtra("mobile"),
                60
                , TimeUnit.SECONDS, verifyphone.this,
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull  PhoneAuthCredential phoneAuthCredential) {

                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        Toast.makeText(verifyphone.this,"Error Please check Internet Connection", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCodeSent(@NonNull  String newbackendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                       getotpbackend=newbackendotp;
                        Toast.makeText(verifyphone.this, "OTP send Successfully", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }
});
    }

    private void numberotpmove() {
        inputnumber1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    inputnumber2.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputnumber2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    inputnumber3.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputnumber3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    inputnumber4.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputnumber4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    inputnumber5.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        inputnumber5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    inputnumber6.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


    }
}