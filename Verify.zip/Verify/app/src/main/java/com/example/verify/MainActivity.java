package com.example.verify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {


    EditText enternumber;
    Button getotpbutton;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        enternumber=findViewById(R.id.mobilenumber);
        getotpbutton=findViewById(R.id.Contnuie);

        getotpbutton.setOnClickListener(v -> {
            if(!enternumber.getText().toString().trim().isEmpty()){
                if((enternumber.getText().toString().trim()).length()==10){
                    PhoneAuthProvider.getInstance().verifyPhoneNumber(
                            "+91" + enternumber.getText().toString(), 60
                            , TimeUnit.SECONDS, MainActivity.this,
                            new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                @Override
                                public void onVerificationCompleted(@NonNull  PhoneAuthCredential phoneAuthCredential) {

                                }

                                @Override
                                public void onVerificationFailed(@NonNull FirebaseException e) {
                                    Toast.makeText(MainActivity.this,"Error Please check Internet Connection", Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void onCodeSent(@NonNull  String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {

                                    Intent intent=new Intent(getApplicationContext(),verifyphone.class);
                                    intent.putExtra("mobile", enternumber.getText().toString());
                                    intent.putExtra("backendotp",backendotp);
                                    startActivity(intent);
                                }
                            }
                    );
//
//                    Intent intent=new Intent(getApplicationContext(),verifyphone.class);
//                    intent.putExtra("mobile",enternumber.getText().toString());
//                    startActivity(intent);
                }else{
                    Toast.makeText(MainActivity.this,"Please enter correct number", Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(MainActivity.this, "Please enter Mobile number", Toast.LENGTH_SHORT).show();
            }
        });


    }

}